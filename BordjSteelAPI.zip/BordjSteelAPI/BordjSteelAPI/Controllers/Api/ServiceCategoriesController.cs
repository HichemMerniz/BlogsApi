﻿using BordjSteelAPI.Data.Dtos.Services;
using BordjSteelAPI.Data.Repositories.ServiceCategories;
using BordjSteelAPI.Data.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;

namespace BordjSteelAPI.Controllers.Api
{
    [Authorize]
    [Route("api/services-categories")]
    [ApiController]
    public class ServiceCategoriesController : Controller
    {
        private readonly IServiceCategoryRepository _serviceCategoryRepository;
        private BordjSteelDBContext _bordjSteelDBContext;


        public ServiceCategoriesController(IServiceCategoryRepository serviceCategoryRepository, BordjSteelDBContext bordjSteelDBContext)
        {
            _bordjSteelDBContext = bordjSteelDBContext;
            _serviceCategoryRepository = serviceCategoryRepository;
        }

        [HttpGet]
        public ActionResult<List<ServicesCategories>> GetAll() => _serviceCategoryRepository.GetAllServiceCategories();

        [HttpGet("{id}")]
        public ActionResult<ServicesCategories> GetOneCategory(Guid id) => _serviceCategoryRepository.Get(id);

        [HttpPost]

        public IActionResult Create(ServiceCategoriesDto serviceCategoryDto)
        {
            var serviceCategory = new ServicesCategories
            {
                Name = serviceCategoryDto.Name,
                Description = serviceCategoryDto.Description,
            };
            _serviceCategoryRepository.Add(serviceCategory);
            
            return Ok(new { message = "success", data = serviceCategory });
        }

        [HttpPut("{id}")]
        public ActionResult Put(Guid Id, ServiceCategoriesDto serviceCategoryDto )
        {
            var serviceCategory = _bordjSteelDBContext.Set<ServicesCategories>().FirstOrDefault(b => b.Id == Id);
            if (serviceCategory != null)
            {
                serviceCategory.Name= serviceCategoryDto.Name;
                serviceCategory.Description = serviceCategoryDto.Description;
            }
            var serviceCategoryDtoUpdated = _serviceCategoryRepository.Update(serviceCategory);
            _bordjSteelDBContext.SaveChanges();
            if (serviceCategoryDtoUpdated  == null)
            {
                return BadRequest();
            }
            return Ok($"success");
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(Guid id)
        {
            var serviceCategory = _serviceCategoryRepository.Delete(id);
            if (serviceCategory == null)
            {
                return BadRequest();
            }
            return Ok("delete success");
        }
    }
}

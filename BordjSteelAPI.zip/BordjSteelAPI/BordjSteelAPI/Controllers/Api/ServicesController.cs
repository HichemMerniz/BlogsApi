﻿using BordjSteelAPI.Data.Dtos.Services;
using BordjSteelAPI.Data.Models;
using BordjSteelAPI.Data.Repositories.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BordjSteelAPI.Controllers.Api
{
    [Authorize]
    [Route("api/services")]
    [ApiController]
    public class ServicesController : Controller
    {
        private readonly IServiceRepository _serviceRepository;
        private BordjSteelDBContext _bordjSteelDBContext;

        public ServicesController(IServiceRepository serviceRepository, BordjSteelDBContext bordjSteelDBContext)
        {
            _serviceRepository = serviceRepository;
            _bordjSteelDBContext = bordjSteelDBContext; 
        }
        [HttpGet]
        public ActionResult<List<Service>> GetAll() => _serviceRepository.GetAllServices();

        [HttpGet("{id}")]
        public ActionResult<Service> GetOneCategory(Guid id) => _serviceRepository.Get(id);

        [HttpPost]

        public IActionResult Create(ServicesDto serviceDto)
        {
            var service = new Service
            {
               
                Name = serviceDto.Name, 
                Description = serviceDto.Description,
                Type = serviceDto.Type,
                ServicesCategoriesId = serviceDto.ServiceCategories_Id

            };
            _serviceRepository.Add(service);

            return Ok(new { message = "success", data = service});
        }

        [HttpPut("{id}")]
        public ActionResult Put(Guid Id, ServicesDto serviceDto)
        {
            var service = _bordjSteelDBContext.Set<Service>().FirstOrDefault(b => b.Id == Id);
            if (service != null)
            {
                service.Name = serviceDto.Name;
                service.Description = serviceDto.Description;
                service.Type = serviceDto.Type;
                service.ServicesCategoriesId = serviceDto.ServiceCategories_Id;
            }
            var serviceDtoUpdated = _serviceRepository.Update(service);
            _bordjSteelDBContext.SaveChanges();
            if (serviceDtoUpdated == null)
            {
                return BadRequest();
            }
            return Ok($"success");
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(Guid id)
        {
            var service = _serviceRepository.Delete(id);
            if (service == null)
            {
                return BadRequest();
            }
            return Ok("delete success");
        }
    }
}

    

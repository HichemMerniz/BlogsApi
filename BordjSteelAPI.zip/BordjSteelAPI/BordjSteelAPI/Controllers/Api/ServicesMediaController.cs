﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using BordjSteelAPI.Data.Repositories.ServiceMedia;
using BordjSteelAPI.Data.Models;
using System.Collections.Generic;
using System;
using BordjSteelAPI.Data.Dtos.Services;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace BordjSteelAPI.Controllers.Api
{
    [Route("api/services-media")]
    [ApiController]
    public class ServicesMediaController : Controller
    {
        private readonly IServiceMediaRepository _serviceMediaRepository;
        private BordjSteelDBContext _bordjSteelDBContext;
        private readonly IWebHostEnvironment _hostEvironment;

        public ServicesMediaController(IWebHostEnvironment hostEvironment, BordjSteelDBContext bordjSteelDBContext,IServiceMediaRepository serviceMediaRepository)
        {
            _bordjSteelDBContext = bordjSteelDBContext;
            _serviceMediaRepository = serviceMediaRepository;
            _hostEvironment = hostEvironment;
        }
        [HttpGet]
        public ActionResult<List<ServicesMedia>> GetAll() => _serviceMediaRepository.GetAllServiceMedia();

        [HttpGet("{id}")]
        public ActionResult<ServicesMedia> GetOne(Guid id) => _serviceMediaRepository.Get(id);

        [HttpPost]

        public async Task<IActionResult> Create([FromForm]ServiceMediaDto serviceMediaDto)
        {
            var link = await SaveImage(serviceMediaDto.File);
            var serviceMedia = new ServicesMedia
            {
                Name = serviceMediaDto.Name,
                Description = serviceMediaDto.Description,
                Link = $"{this.Request.Scheme}://{this.Request.Host}/image/{link}",
                ServiceId = serviceMediaDto.ServiceId,
            };
            _serviceMediaRepository.Add(serviceMedia);

            return Ok(new { message = "success", data = serviceMedia });
        }

        [HttpPut("{id}")]
        public ActionResult Put(Guid Id, ServiceMediaDto serviceMediaDto)
        {
            var serviceMedia = _bordjSteelDBContext.Set<ServicesMedia>().FirstOrDefault(b => b.Id == Id);
            if (serviceMedia != null)
            {
                serviceMedia.Name = serviceMediaDto.Name;
                serviceMedia.Description = serviceMediaDto.Description;
            }
            var serviceMediaDtoUpdated = _serviceMediaRepository.Update(serviceMedia);
            _bordjSteelDBContext.SaveChanges();
            if (serviceMediaDtoUpdated == null)
            {
                return BadRequest();
            }
            return Ok($"success");
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(Guid id)
        {
            var serviceMedia = _serviceMediaRepository.Delete(id);
            if (serviceMedia == null)
            {
                return BadRequest();
            }
            return Ok("delete success");
        }
        [NonAction]
        public async Task<string> SaveImage(IFormFile imageFile)
        {
            string imageName = new String(Path.GetFileNameWithoutExtension(imageFile.FileName).Take(10).ToArray()).Replace(' ', '-');
            imageName = imageName + DateTime.Now.ToString("yymmssfff") + Path.GetExtension(imageFile.FileName);
            var imagePath = Path.Combine(_hostEvironment.ContentRootPath, "Image", imageName);
            Path.GetPathRoot(imagePath);
            using (var fileStream = new FileStream(imagePath, FileMode.Create))
            {
                await imageFile.CopyToAsync(fileStream);
            }
            return imageName; 
        }
    }
}

﻿using BordjSteelAPI.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BordjSteelAPI.Data.Dtos.Services
{
    public class ServiceCategoriesDto
    {
        public Guid Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
        public string Description { get; set; }

        public List<Service> Services { get; set; }
    }
}

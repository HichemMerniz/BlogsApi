﻿using Microsoft.AspNetCore.Http;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BordjSteelAPI.Data.Dtos.Services
{
    public class ServiceMediaDto
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
        public string Description { get; set; }
        [NotMapped]
        public IFormFile File { get; set; }
      
        [Required(ErrorMessage = "Service ID is required")]
        public Guid ServiceId { get; set; }
    }
}

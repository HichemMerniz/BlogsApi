﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BordjSteelAPI.Data.Dtos.Services
{
    public class ServicesDto
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type{ get; set; }

        [Required(ErrorMessage = "Service Category ID is required")]
        public Guid ServiceCategories_Id { get; set; }
        }
}

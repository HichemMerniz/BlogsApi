﻿using System.ComponentModel.DataAnnotations;

namespace BordjSteelAPI.Data.Models
{
    public class ProductCategories
    {
        [Key]
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
    }
}

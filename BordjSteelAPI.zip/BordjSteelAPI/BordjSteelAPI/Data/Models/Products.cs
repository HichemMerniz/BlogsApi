﻿using System;
using System.ComponentModel.DataAnnotations;
namespace BordjSteelAPI.Data.Models
{
    public class Products
    {
        [Key]
        public int Id {get; set;}
        public string Title {get; set;}
        public string Description {get; set;}

        public Guid productCategories_id { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BordjSteelAPI.Data.Models
{
    public class Service
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        
        /*Rolationship*/
        public List<ServicesMedia> ServicesMedia{ get; set; }
        public Guid ServicesCategoriesId { get; set; }


    }
}

﻿using Microsoft.AspNetCore.Http;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BordjSteelAPI.Data.Models
{
    public class ServicesMedia
    {
        [Key]
        public Guid Id {get; set;}
        public string Name {get; set;}
        public string Description {get; set;}
        public string Link {get; set;}
        
        public Guid ServiceId { get; set; }
      
    }
}

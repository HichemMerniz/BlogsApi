﻿using Microsoft.AspNetCore.Identity;
using System;

namespace BordjSteelAPI.Data.Models
{
    public class Users : IdentityUser<Guid>
    {
        public DateTime Birthday { get; set; }
        public string ProfilImage { get; set; }

        /*Rolationship*/

    }
}

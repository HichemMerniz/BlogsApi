﻿using BordjSteelAPI.Data.Models;
using System;
using System.Collections.Generic;

namespace BordjSteelAPI.Data.Repositories.ServiceCategories
{
    public interface IServiceCategoryRepository
    {
        List<ServicesCategories> GetAllServiceCategories();
        ServicesCategories Get(Guid id);
        ServicesCategories Add(ServicesCategories servicesCategory);
        ServicesCategories Update(ServicesCategories servicesCategory);
        ServicesCategories Delete(Guid id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using BordjSteelAPI.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace BordjSteelAPI.Data.Repositories.ServiceCategories
{
    public class ServiceCategoriesRepository : IServiceCategoryRepository
    {
        private readonly BordjSteelDBContext _bordjSteelDBContext;

        public ServiceCategoriesRepository(BordjSteelDBContext bordjSteelDBContext)
        {
            _bordjSteelDBContext = bordjSteelDBContext;
        }
        public ServicesCategories Add(ServicesCategories servicesCategory)
        {
            _bordjSteelDBContext.Set<ServicesCategories>().Add(servicesCategory);
            _bordjSteelDBContext.SaveChanges();
            return servicesCategory;
        }



        public ServicesCategories Delete(Guid id)
        {
            var serviceCategory = _bordjSteelDBContext.Set<ServicesCategories>().FirstOrDefault(b => b.Id == id);
            if (serviceCategory == null)
            {
                return serviceCategory;
            }
            _bordjSteelDBContext.Set<ServicesCategories>().Remove(serviceCategory);
            _bordjSteelDBContext.SaveChanges();
            return serviceCategory;
        }

        public ServicesCategories Get(Guid id)
        {
           // return _bordjSteelDBContext.Set<ServicesCategories>().Find(id);
            return _bordjSteelDBContext.ServiceCategories.Include(a => a.Services).ThenInclude(s=>s.ServicesMedia).SingleOrDefault(b => b.Id == id);
        }

        public List<ServicesCategories> GetAllServiceCategories()
        {
            
            return _bordjSteelDBContext.ServiceCategories.Include(a => a.Services).ThenInclude(s => s.ServicesMedia).ToList();
        }


        public ServicesCategories Update(ServicesCategories servicesCategoryChange)
        {
            var serviceCategory = _bordjSteelDBContext.Set<ServicesCategories>().FirstOrDefault(b => b.Id == servicesCategoryChange.Id);

            if (serviceCategory == null)
            {
                return serviceCategory;
            }
            _bordjSteelDBContext.Set<ServicesCategories>().Update(servicesCategoryChange);
            _bordjSteelDBContext.SaveChanges();
            /* if(blog != null)
             {
                     blog.Title = blogChanges.Title;
                     blog.Description=blogChanges.Description;
                     blog.Images=blogChanges.Images;
                     blog.AuthorId=blogChanges.AuthorId;
             };            
             _blogDBContext.SaveChanges();*/

            return servicesCategoryChange;
        }


    }
}

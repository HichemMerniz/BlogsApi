﻿using BordjSteelAPI.Data.Models;
using System;
using System.Collections.Generic;

namespace BordjSteelAPI.Data.Repositories.ServiceMedia
{
    public interface IServiceMediaRepository
    {
        List<ServicesMedia> GetAllServiceMedia();
        ServicesMedia Get(Guid id);
        ServicesMedia Add(ServicesMedia servicesMedia);
        ServicesMedia Update(ServicesMedia servicesMediaChange);
        ServicesMedia Delete(Guid id);
    }
}

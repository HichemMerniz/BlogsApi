﻿using BordjSteelAPI.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BordjSteelAPI.Data.Repositories.ServiceMedia
{
    public class ServiceMediaRepository : IServiceMediaRepository
    {
        private readonly BordjSteelDBContext _bordjSteelDBContext;
        public ServiceMediaRepository(BordjSteelDBContext bordjSteelDBContext)
        {
            _bordjSteelDBContext = bordjSteelDBContext;
        }


        public ServicesMedia Add(ServicesMedia servicesMedia)
        {
            _bordjSteelDBContext.Set<ServicesMedia>().Add(servicesMedia);
            _bordjSteelDBContext.SaveChanges();
            return servicesMedia;
        }

        public ServicesMedia Delete(Guid id)
        {
            var serviceMedia = _bordjSteelDBContext.Set<ServicesMedia>().FirstOrDefault(b => b.Id == id);
            if (serviceMedia == null)
            {
                return serviceMedia;
            }
            _bordjSteelDBContext.Set<ServicesMedia>().Remove(serviceMedia);
            _bordjSteelDBContext.SaveChanges();
            return serviceMedia;
        }

        public ServicesMedia Get(Guid id)
        {
            return _bordjSteelDBContext.Set<ServicesMedia>().Find(id);
        }

        public List<ServicesMedia> GetAllServiceMedia()
        {
            return _bordjSteelDBContext.Set<ServicesMedia>().ToList();
        }

        public ServicesMedia Update(ServicesMedia servicesMediaChange)
        {
            var serviceMedia = _bordjSteelDBContext.Set<ServicesMedia>().FirstOrDefault(b => b.Id == servicesMediaChange.Id);

            if (serviceMedia == null)
            {
                return serviceMedia;
            }
            _bordjSteelDBContext.Set<ServicesMedia>().Update(servicesMediaChange);
            _bordjSteelDBContext.SaveChanges();
            /* if(blog != null)
             {
                     blog.Title = blogChanges.Title;
                     blog.Description=blogChanges.Description;
                     blog.Images=blogChanges.Images;
                     blog.AuthorId=blogChanges.AuthorId;
             };            
             _blogDBContext.SaveChanges();*/

            return servicesMediaChange;
        }
    }
}

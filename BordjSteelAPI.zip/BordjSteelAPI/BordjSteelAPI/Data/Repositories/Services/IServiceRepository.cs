﻿using System;
using System.Collections.Generic;
using BordjSteelAPI.Data.Models;

namespace BordjSteelAPI.Data.Repositories.Services
{
    public interface IServiceRepository
    {
        List<Service> GetAllServices();
        Service Get(Guid id);
        Service Add(Service services);
        Service Update(Service services);
        Service Delete(Guid id);
    }
}

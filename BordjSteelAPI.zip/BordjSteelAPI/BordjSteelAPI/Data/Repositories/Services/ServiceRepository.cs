﻿using BordjSteelAPI.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BordjSteelAPI.Data.Repositories.Services
{
    public class ServiceRepository : IServiceRepository
    {
        private readonly BordjSteelDBContext _bordjSteelDBContext;
        public ServiceRepository(BordjSteelDBContext bordjSteelDBContext)
        {
            _bordjSteelDBContext = bordjSteelDBContext;
        }
        public Service Add(Service services)
        {
            _bordjSteelDBContext.Set<Service>().Add(services);
            _bordjSteelDBContext.SaveChanges();
            return services;
        }

        public Service Delete(Guid id)
        {
            var service= _bordjSteelDBContext.Set<Service>().FirstOrDefault(b => b.Id == id);
            if (service == null)
            {
                return service;
            }
            _bordjSteelDBContext.Set<Service>().Remove(service);
            _bordjSteelDBContext.SaveChanges();
            return service;
        }

        public Service Get(Guid id)
        {
            return _bordjSteelDBContext.Services.Include(a => a.ServicesMedia).SingleOrDefault(b => b.Id == id);
        }

        public List<Service> GetAllServices()
        {
            return _bordjSteelDBContext.Services.Include(a => a.ServicesMedia).ToList();
        }

        public Service Update(Service serviceChange)
        {
            var service = _bordjSteelDBContext.Set<Service>().FirstOrDefault(b => b.Id == serviceChange.Id);

            if (service == null)
            {
                return service;
            }
            _bordjSteelDBContext.Set<Service>().Update(serviceChange);
            _bordjSteelDBContext.SaveChanges();
            return serviceChange;
        }
    }
}

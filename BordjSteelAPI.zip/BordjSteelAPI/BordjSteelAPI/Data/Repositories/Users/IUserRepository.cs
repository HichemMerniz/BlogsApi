﻿namespace BordjSteelAPI.Data.Repositories.Users
{
    public interface IUserRepository
    {
    }
}
